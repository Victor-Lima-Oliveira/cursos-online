<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	include "conexao.php";
	
	if($con != null){

		$idCurso = $_POST['idCurso'];
		$nomeCurso = $_POST['nomeCurso'];
		$duracaoCurso = $_POST['duracaoCurso'];
		$valorCurso = $_POST['valorCurso'];
		
		$updateCurso = "update tbl_curso set 
							nome = '$nomeCurso', 
							valor = $valorCurso,
							duracao = $duracaoCurso
							where id = $idCurso;";
		
		if(mysqli_query($con, $updateCurso))
			echo "TRUE";
		else echo "FALSE";
		
		
	}
}
else 
	echo "Método inválido!";


?>
