<?php //return json
require_once 'usuario_select.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	include "conexao.php";
	if($con != null){
		if(!isset($_POST['usuarioNome']) ||  !isset($_POST['usuarioSenha']) || 
		   !isset($_POST['usuarioEmail']) ||  !isset($_POST['usuarioAcesso']))
		{
			$array_response['status'] = "Falta parametros";
			echo json_encode($array_response);
			die();
		}
			
		$usuarioNome = $_POST['usuarioNome'];
		$usuarioEmail = $_POST['usuarioEmail'];
		$usuarioSenha = $_POST['usuarioSenha'];
		$usuarioAcesso = $_POST['usuarioAcesso'];
		

		$array_response = [];

		$usuarioAcesso = ($usuarioAcesso === "true") ? 1 : 0;
		$usuarioSenha = password_hash($usuarioSenha, PASSWORD_DEFAULT);
		$usuarioEmail = strtolower($usuarioEmail);
	
				
		if(!selectEmail($usuarioEmail)){		
			$insertUsuario = "insert into tbl_usuario values
															(NULL,
															'$usuarioNome', 
															'$usuarioEmail', 
															'$usuarioSenha', 
															'$usuarioAcesso');";
			
			if(mysqli_query($con, $insertUsuario))
			{
				$selectID = "select * from tbl_usuario where usuarioEmail = '$usuarioEmail';";
				$stmt = $con-> prepare($selectID);
				$stmt -> execute();
				$stmt -> bind_result($usuarioId,$usuarioNome,$usuarioEmail,$usuarioSenha,$usuarioAcesso);
	
				if($stmt -> fetch()){
					$array_response['status'] = "Cadastrado";
					$array_response['usuarioId'] = $usuarioId;
					($usuarioAcesso == 1) ? $array_response['usuarioAcesso'] = true : $array_response['usuarioAcesso']  = false;
				}
			}
			else 
				$array_response['status'] = "Nao foi possivel cadastar";
		}
		else 
			$array_response['status'] = "Email ja cadastrado";
		echo json_encode($array_response);
	}
}
else 
	echo "Método inválido!";

?>