<?php 

	try{
		$con = mysqli_connect("localhost","root","root","REST_MyApi", "3306")
		or die ("Problemas com a conexão, chame um técnico");

	}catch(Exception $e){
		$con = null;
		echo "Erro: $e";
	}

?>