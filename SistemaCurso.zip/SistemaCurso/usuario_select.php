<?php

	function selectEmail($email){
		include "conexao.php";

		$selectEmail = "select * from tbl_usuario where usuarioEmail = '$email';";
		$stmt = $con-> prepare($selectEmail);
		$stmt -> execute();
		$stmt -> bind_result($usuarioId,$usuarioNome,$usuarioEmail,$usuarioSenha,$usuarioAcesso);
		
		if($stmt -> fetch())
			return true;
		else 
			return false;
		
	}
	
	function selectPass($password){
		include "conexao.php";

		$selectEmail = "select * from tbl_usuario where usuarioEmail = '$email';";
		$stmt = $con-> prepare($selectEmail);
		$stmt -> execute();
		$stmt -> bind_result($usuarioId,$usuarioNome,$usuarioEmail,$usuarioSenha,$usuarioAcesso);
		
		if($stmt -> fetch())
			return true;
		else 
			return false;
		
	}
	
	
	function selectID(){
		if($_SERVER['REQUEST_METHOD'] == 'GET'){
			include 'conexao.php';
			
			if(isset($_GET['usuarioId'])){
				if($con != null){
					
					$usuarioId = $_GET['usuarioId'];
					$arrayUsuario = [];
					
					$selectUsuario = "select * from tbl_usuario where usuarioId = $usuarioId";
					$stmt = $con-> prepare($selectUsuario);
					$stmt -> execute();
					$stmt -> bind_result($usuarioId,$usuarioNome,$usuarioEmail,$usuarioSenha,$usuarioAcesso);
					
					if($stmt ->fetch()){
						do{
							$arrayUsuario['usuarioId'] = $usuarioId;
							$arrayUsuario['usuarioNome'] = $usuarioNome;
							$arrayUsuario['usuarioEmail'] = $usuarioEmail;
							$arrayUsuario['usuarioSenha'] = $usuarioSenha;
							$arrayUsuario['usuarioAcesso'] = $usuarioAcesso;
						}while($stmt->fetch());
						echo json_encode ($arrayUsuario);
					}
					else
						echo json_encode("Usuario nao cadastrado no sistema");
					
				}
			}
			else  
				echo "Id não informado";
		} // end server == GET
		else 
			echo "Método inválido!";
	}


		

?>