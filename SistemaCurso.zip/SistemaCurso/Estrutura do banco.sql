create database REST_MyApi;
use REST_MyApi;

create table tbl_curso(
id int primary key auto_increment,
nome varchar(200),
duracao int,
valor decimal(8,2));

create table tbl_usuario(
usuarioId int primary key auto_increment,
usuarioNome varchar(50) not null,
usuarioEmail varchar(200) not null unique,	
usuarioSenha varchar(60) not null,
usuarioAcesso Boolean);




