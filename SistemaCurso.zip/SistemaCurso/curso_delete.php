<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	include "conexao.php";
	if($con != null){

		$idCurso = $_POST['idCurso'];

		
		$deleteCurso = "delete from tbl_curso where id = $idCurso;";
		
		if(mysqli_query($con, $deleteCurso))
			echo "TRUE";
		else echo "FALSE";
		
		
	}
}
else 
	echo "Método inválido!";


?>
