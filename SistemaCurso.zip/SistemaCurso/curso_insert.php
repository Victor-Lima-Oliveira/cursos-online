<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	include "conexao.php";
	if($con != null){

		$nomeCurso = $_POST['nomeCurso'];
		$duracaoCurso = $_POST['duracaoCurso'];
		$valorCurso = $_POST['valorCurso'];
		
		$insertCurso = "insert into tbl_curso values (null, '$nomeCurso', $duracaoCurso, $valorCurso);";
		
		if(mysqli_query($con, $insertCurso))
			echo "TRUE";
		else echo "FALSE";
		
		
	}
}
else 
	echo "Método inválido!";


?>
