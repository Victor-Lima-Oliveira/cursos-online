<?php

if($_SERVER['REQUEST_METHOD'] == 'GET'){

include 'conexao.php';

if($con != null){
	
	$valorMaximo = $_GET['valorMaximo'];
	
	$arrayCurso = [];
	
	$selectCurso = "select * from tbl_curso where valor <= '$valorMaximo'";
	$stmt = $con-> prepare($selectCurso);
	$stmt -> execute();
	$stmt->bind_result($id,$nomeCurso,$duracaoCurso,$valorCurso);
	
	while($stmt->fetch()){
		$temp =[
		'idCurso' => $id,
		'nomeCurso' => $nomeCurso,
		'duracaoCurso' => $duracaoCurso,
		'valorCurso' => $valorCurso
		];
		
		array_push($arrayCurso, $temp);
	}
	echo json_encode ($arrayCurso);
}
}
else 
	echo "Método inválido!";
	


?>