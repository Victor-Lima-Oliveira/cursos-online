<?php //return json
require_once 'usuario_select.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	include "conexao.php";
	if($con != null){
		if(  !isset($_POST['usuarioSenha']) || !isset($_POST['usuarioEmail']))
		{
			$array_response['status'] = "Falta parametros";
			echo json_encode($array_response);
			die();
		}
			
		$usuarioEmail = $_POST['usuarioEmail'];
		$usuarioSenhaDigitado = $_POST['usuarioSenha'];
		$usuarioEmail = strtolower($usuarioEmail);

		
		$array_response = [];
				
		if(!selectEmail($usuarioEmail))
			$array_response['status'] = "Usuario nao cadastrado no sistema";
		else{
			$selectlogin = "select * from tbl_usuario where usuarioEmail = '$usuarioEmail'";
			$stmt = $con-> prepare($selectlogin);
			$stmt -> execute();
			$stmt -> bind_result($usuarioId,$usuarioNome,$usuarioEmail,$usuarioSenha,$usuarioAcesso);
		
			if($stmt -> fetch()){
				if(password_verify($usuarioSenhaDigitado, $usuarioSenha)){
					$array_response['status'] = "logon";
					$array_response['usuarioId'] = $usuarioId;
					$array_response['usuarioAcesso'] = ($usuarioAcesso == 1) ? true : false;
				}
				else 
					$array_response['status'] = "Usuario ou senha incorretos";
			}		
		}

		echo json_encode($array_response);
	}
}
else 
	echo "Método inválido!";

?>