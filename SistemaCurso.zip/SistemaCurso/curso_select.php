<?php

if($_SERVER['REQUEST_METHOD'] == 'GET'){

include 'conexao.php';

if($con != null){
	
	
	$arrayCurso = [];
	
	$selectCurso = "select * from tbl_curso";
	$stmt = $con-> prepare($selectCurso);
	$stmt -> execute();
	$stmt->bind_result($id,$nomeCurso,$duracaoCurso,$valorCurso);
	
	while($stmt->fetch()){
		$temp =[
		'idCurso' => $id,
		'nomeCurso' => $nomeCurso,
		'duracaoCurso' => $duracaoCurso,
		'valorCurso' => $valorCurso
		];
		
		array_push($arrayCurso, $temp);
	}
	echo json_encode ($arrayCurso);
}
}
else 
	echo "Método inválido!";
	


?>